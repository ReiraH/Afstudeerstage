// This header is NOT generated.

#ifndef _CkSettings_H
#define _CkSettings_H
	
#include "Chilkat_C.h"

static void CkSettings_cleanupMemory(void);
static void CkSettings_initializeMultithreaded(void);

#endif
